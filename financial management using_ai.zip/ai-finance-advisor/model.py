def analyze_expenses(expenses):
    total = sum(expenses)
    avg = total / len(expenses) if expenses else 0

    advice = ""
    if avg > 100:
        advice = "Try reducing your daily average spending. Set a budget goal."
    elif avg < 50:
        advice = "Great job! You're spending wisely. Consider investing savings."
    else:
        advice = "Your spending is moderate. Track categories for better planning."

    return {
        "total": total,
        "average": avg,
        "advice": advice
    }
