from flask import Flask, render_template, request, jsonify
import pandas as pd
from model import analyze_expenses

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    data = request.get_json()
    expenses = data.get("expenses", [])
    response = analyze_expenses(expenses)
    return jsonify(response)

if __name__ == '__main__':
    app.run(debug=True)
